`app.css` is a compiled from `resources/less/*.less`.

Modify the LESS files.

The CSS is recompiled on each build.

Manually compile the LESS with `npm run less`.
